package com.example.Email.Registration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailRegistrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
