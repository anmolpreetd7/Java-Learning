package com.example.Email.Registration.appuser;

public enum AppUserRole {
    USER,
    ADMIN
}
