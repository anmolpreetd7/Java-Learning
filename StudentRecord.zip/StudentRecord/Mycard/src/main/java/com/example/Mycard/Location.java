package com.example.Mycard;

import lombok.*;

import javax.persistence.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity(name = "Location")
@Table(name = "location")
public class Location {

    @Id
    @SequenceGenerator(
            name = "location_sequence",
            sequenceName = "location_sequence",
            allocationSize = 1
    )
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "location_sequence"
    )
    @Column(name = "id",updatable = false)
    private Long id;

    @Column(name = "location_name",nullable = false,columnDefinition = "TEXT")
    private String locationName;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "employment_id",referencedColumnName = "id",
            foreignKey = @ForeignKey(name = "location_employment_id_fk")
    )
    private Employment employment;

    public Location(String locationName){
        this.locationName = locationName;
    }
}
