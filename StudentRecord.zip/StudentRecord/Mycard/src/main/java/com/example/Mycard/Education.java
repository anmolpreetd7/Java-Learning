package com.example.Mycard;

import lombok.*;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity(name = "Education")
@Table(name = "education")
public class Education {

    @Id
    @SequenceGenerator(
            name = "education_sequence",
            sequenceName = "education_sequence",
            allocationSize = 1
    )
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "education_sequence"
    )
    @Column(name = "id",updatable = false)
    private Long id;

    @Column(name = "program_name",nullable = false,columnDefinition = "TEXT")
    private String programName;

    @Column(name = "program_length",nullable = false,columnDefinition = "DATE")
    private LocalDate finishedDate;

    @Column(name = "field_of_study",nullable = false,columnDefinition = "TEXT")
    private String fieldOfStudy;

    @OneToMany(cascade = {CascadeType.PERSIST,CascadeType.REMOVE},mappedBy = "education")
    private List<Enrolment> enrolments = new ArrayList<>();

    public Education(Long id,String programName, LocalDate finishedDate, String fieldOfStudy){
        this.programName = programName;
        this.finishedDate = finishedDate;
        this.fieldOfStudy = fieldOfStudy;
    }

    public Education(String programName, LocalDate finishedDate, String fieldOfStudy){
        this.programName = programName;
        this.finishedDate = finishedDate;
        this.fieldOfStudy = fieldOfStudy;
    }

    public void addEnrol(Enrolment enrolment){
        if(!this.enrolments.contains(enrolment)){
            this.enrolments.add(enrolment);
            enrolment.setEducation(this);
        }
    }

    public void removeEnrol(Enrolment enrolment){
        if(this.enrolments.contains(enrolment)){
            this.enrolments.remove(enrolment);
            enrolment.setEducation(null);
        }
    }
}
