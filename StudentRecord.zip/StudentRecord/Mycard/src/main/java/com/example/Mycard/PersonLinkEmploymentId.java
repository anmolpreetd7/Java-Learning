package com.example.Mycard;

import lombok.*;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@Embeddable
public class PersonLinkEmploymentId implements Serializable {

    @Column(name = "person_id")
    private Long personId;

    @Column(name = "employment_id")
    private Long employmentId;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PersonLinkEmploymentId that = (PersonLinkEmploymentId) o;
        return Objects.equals(personId, that.personId) && Objects.equals(employmentId, that.employmentId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(personId, employmentId);
    }
}
