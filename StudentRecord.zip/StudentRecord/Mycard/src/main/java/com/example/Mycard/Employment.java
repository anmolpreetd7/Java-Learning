package com.example.Mycard;

import lombok.*;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity(name = "Employment")
@Table(name = "employment")
public class Employment {

    @Id
    @SequenceGenerator(
            name = "employment_sequence",
            sequenceName = "employment_sequence",
            allocationSize = 1
    )
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "employment_sequence"
    )
    @Column(name = "id",updatable = false)
    private Long id;

    @Column(name = "title",nullable = false,columnDefinition = "TEXT")
    private String title;

    @Column(name = "start_date",nullable = false,columnDefinition = "DATE")
    private LocalDate startDate;

    @Column(name = "current_work",nullable = false,columnDefinition = "BOOLEAN")
    private Boolean currentWork;

    @OneToMany(cascade = CascadeType.ALL,
            mappedBy = "employment",
            orphanRemoval = true)
    private List<Location> locations = new ArrayList<>();

    @OneToMany(cascade = {CascadeType.PERSIST,CascadeType.REMOVE},mappedBy = "employment",orphanRemoval = true)
    private List<PersonLinkEmployment> personLinkEmployments = new ArrayList<>();

    public Employment(Long id,String title,LocalDate startDate,Boolean currentWork){
        this.id = id;
        this.title = title;
        this.startDate = startDate;
        this.currentWork = currentWork;
    }

    public Employment(String title,LocalDate startDate,Boolean currentWork){
        this.title = title;
        this.startDate = startDate;
        this.currentWork = currentWork;
    }
    @Transactional
    public void addLocation(Location location){
        if(!this.locations.contains(location)){
            this.locations.add(location);
            location.setEmployment(this);
        }
    }

    public void removeLocation(Location location){
        if(this.locations.contains(location)){
            this.locations.remove(location);
            location.setEmployment(null);
        }
    }

    public void addPersonLinkEmployment(PersonLinkEmployment personLinkEmployment){
        if(!this.personLinkEmployments.contains(personLinkEmployment)){
            this.personLinkEmployments.add(personLinkEmployment);
            personLinkEmployment.setEmployment(this);
        }
    }

    public void removePersonLinkEmployment(PersonLinkEmployment personLinkEmployment){
        if(this.personLinkEmployments.contains(personLinkEmployment)){
            this.personLinkEmployments.remove(personLinkEmployment);
            personLinkEmployment.setEmployment(null);
        }
    }
}
