package com.example.Mycard;

import lombok.*;

import javax.persistence.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity(name = "PersonLinkEmployment")
@Table(name = "person_link_employment")
public class PersonLinkEmployment {

    @EmbeddedId
    private PersonLinkEmploymentId id;

    @ManyToOne(cascade = {CascadeType.PERSIST,CascadeType.REMOVE})
    @MapsId("personId")
    @JoinColumn(name = "person_id",referencedColumnName = "id",
            foreignKey = @ForeignKey(name = "person_link_employment_person_id_fk")
    )
    private Person person;

    @ManyToOne(cascade = {CascadeType.PERSIST,CascadeType.REMOVE})
    @MapsId("employmentId")
    @JoinColumn(name = "employment_id",referencedColumnName = "id",
        foreignKey = @ForeignKey(name = "person_link_employment_employment_id_ek")
    )
    private Employment employment;
}
