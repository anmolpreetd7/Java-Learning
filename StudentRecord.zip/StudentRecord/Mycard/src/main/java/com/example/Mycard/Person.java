package com.example.Mycard;

import lombok.*;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity(name = "Person")
@Table(name = "person")
public class Person {
    @Id
    @SequenceGenerator(
            name = "person_sequence",
            sequenceName = "person_sequence",
            allocationSize = 1
    )
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "person_sequence"
    )
    @Column(name = "id",updatable = false)
    private Long id;

    @Column(name = "first_name",nullable = false,columnDefinition = "TEXT")
    private String firstName;

    @Column(name = "last_name",nullable = false,columnDefinition = "TEXT")
    private String lastName;

    @Column(name = "date_of_birth",nullable = false,columnDefinition = "DATE")
    private LocalDate dob;

    @Column(name = "address",nullable = false,columnDefinition = "TEXT")
    private String address;

    @OneToMany(cascade = {CascadeType.PERSIST,CascadeType.REMOVE},
        mappedBy = "person",orphanRemoval = true
    )
    private List<PhoneNumber> phoneNumbers = new ArrayList<>();

    @OneToMany(cascade = {CascadeType.PERSIST,CascadeType.REMOVE},mappedBy = "person",
        orphanRemoval = true
    )
    private List<Enrolment> enrolments = new ArrayList<>();

    @OneToMany(cascade = {CascadeType.PERSIST,CascadeType.REMOVE},mappedBy = "person",
    orphanRemoval = true)
    private List<PersonLinkEmployment> personLinkEmployments = new ArrayList<>();

    public Person(String firstName,String lastName,LocalDate dob, String address){
        this.firstName = firstName;
        this.lastName = lastName;
        this.dob = dob;
        this.address = address;
    }
    @Transactional
    public void addPhoneNumber(PhoneNumber phoneNumber){
        if(!this.phoneNumbers.contains(phoneNumber)){
            this.phoneNumbers.add(phoneNumber);
            phoneNumber.setPerson(this);
        }
    }

    public void removePhoneNumber(PhoneNumber phoneNumber){
        if(this.phoneNumbers.contains(phoneNumber)){
            this.phoneNumbers.remove(phoneNumber);
            phoneNumber.setPerson(null);
        }
    }
    @Transactional
    public void addEnrol(Enrolment enrolment){
        if(!this.enrolments.contains(enrolment)){
            this.enrolments.add(enrolment);
            enrolment.setPerson(this);
        }
    }

    public void removeEnrol(Enrolment enrolment){
        if(this.enrolments.contains(enrolment)){
            this.enrolments.remove(enrolment);
            enrolment.setPerson(null);
        }
    }

    @Transactional
    public void addPersonLinkEmployment(PersonLinkEmployment personLinkEmployment){
        if(!this.personLinkEmployments.contains(personLinkEmployment)){
            this.personLinkEmployments.add(personLinkEmployment);
            personLinkEmployment.setPerson(this);
        }
    }

    public void removePersonLinkEmployment(PersonLinkEmployment personLinkEmployment){
        if(this.personLinkEmployments.contains(personLinkEmployment)){
            this.personLinkEmployments.remove(personLinkEmployment);
            personLinkEmployment.setPerson(null);
        }
    }

}
