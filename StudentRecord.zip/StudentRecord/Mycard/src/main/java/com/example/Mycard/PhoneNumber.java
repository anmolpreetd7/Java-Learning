package com.example.Mycard;

import lombok.*;

import javax.persistence.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity(name = "PhoneNumber")
@Table(name = "phone_number",
        uniqueConstraints = @UniqueConstraint(name = "phone_number_unique",columnNames = "number")
)
public class PhoneNumber {

    @Id
    @SequenceGenerator(
            name = "phone_number_sequence",
            sequenceName = "phone_number_sequence",
            allocationSize = 1
    )
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "phone_number_sequence"
    )
    @Column(name = "id",updatable = false)
    private Long id;

    @Column(name = "number",nullable = false,columnDefinition = "TEXT")
    private String number;

    @ManyToOne(cascade = {CascadeType.PERSIST,CascadeType.REMOVE})
    @JoinColumn(
            name = "person_id",
            referencedColumnName = "id",
            foreignKey = @ForeignKey(name = "phone_number_person_id_fk")
    )
    private Person person;

    public PhoneNumber(String number){
        this.number = number;
    }

}
