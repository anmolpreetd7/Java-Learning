package com.example.Mycard;

import lombok.*;

import javax.persistence.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity(name = "Enrolment")
@Table(name = "enrolment")
public class Enrolment {
    @EmbeddedId
    private EnrolmentId id;

    @ManyToOne(cascade = {CascadeType.PERSIST,CascadeType.REMOVE})
    @MapsId("personId")
    @JoinColumn(name = "person_id",referencedColumnName = "id",
        foreignKey = @ForeignKey(name = "enrolment_person_id_fk")
    )
    private Person person;

    @ManyToOne(cascade = {CascadeType.PERSIST,CascadeType.REMOVE})
    @MapsId("educationId")
    @JoinColumn(name = "education_id",referencedColumnName = "id",
        foreignKey = @ForeignKey(name = "enrolment_education_id_fk")
    )
    private Education education;

}
