package com.example.Mycard;

import lombok.*;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@Embeddable
public class EnrolmentId implements Serializable {

    @Column(name = "person_id")
    private Long personId;

    @Column(name = "education_id")
    private Long educationId;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EnrolmentId that = (EnrolmentId) o;
        return Objects.equals(personId, that.personId) && Objects.equals(educationId, that.educationId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(personId, educationId);
    }
}
