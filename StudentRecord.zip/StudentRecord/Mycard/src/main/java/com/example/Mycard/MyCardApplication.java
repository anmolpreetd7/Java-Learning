package com.example.Mycard;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;

@SpringBootApplication
public class MyCardApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyCardApplication.class, args);
	}

	@Bean
	CommandLineRunner commandLineRunner(PersonRepository personRepository,
										EmploymentRepository employmentRepository){
		return args ->{

			Person anmolpreet = new Person("Anmolpreet","Dhindsa",
					LocalDate.of(1998,1,8),
					"Canada");

			anmolpreet.addPhoneNumber(new PhoneNumber("6475469093"));

			anmolpreet.addPhoneNumber(new PhoneNumber("5194359093"));


			anmolpreet.addEnrol(new Enrolment(
					new EnrolmentId(1L,1L),
					anmolpreet,
					new Education(1L,"ITSS", LocalDate.of(2017,8,17), "Information Technology")
			));

			Employment employment = new Employment("Software Engineer", LocalDate.of(2021, 8, 9), true);
			employment.addLocation(new Location("Mississauga"));


			anmolpreet.addPersonLinkEmployment(new PersonLinkEmployment(
					new PersonLinkEmploymentId(1L,1L),
					anmolpreet,
					employment
			));


			personRepository.save(anmolpreet);

		};
	}

}
