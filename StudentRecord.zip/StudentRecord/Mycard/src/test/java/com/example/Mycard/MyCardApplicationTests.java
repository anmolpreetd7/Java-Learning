package com.example.Mycard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyCardApplicationTests {

	@Test
	void contextLoads() {
	}

}
