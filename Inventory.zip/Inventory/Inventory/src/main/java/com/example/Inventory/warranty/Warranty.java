package com.example.Inventory.warranty;

import com.example.Inventory.computer.Computer;
import com.example.Inventory.scanner.Scanner;
import lombok.*;

import javax.persistence.*;
import java.time.LocalDate;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity(name = "Warranty")
@Table(name = "warranty")
public class Warranty {

    @Id
    @SequenceGenerator(
            name = "warranty_sequence",
            sequenceName = "warranty_sequence",
            allocationSize = 1
    )
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "warranty_sequence"
    )
    @Column(name = "id",updatable = false)
    private Long id;

    @Column(name = "period",nullable = false,columnDefinition = "DATE")
    private LocalDate period;

    @Column(name = "in_warranty",nullable = false,columnDefinition = "BOOLEAN")
    private Boolean inWarranty;

    @OneToOne(cascade = CascadeType.ALL,mappedBy = "warranty")
    private Scanner scanner;

    @OneToOne(cascade = CascadeType.ALL,mappedBy = "warranty")
    private Computer computer;

    public Warranty(LocalDate period,Boolean inWarranty){
        this.period = period;
        this.inWarranty = inWarranty;
    }
}
