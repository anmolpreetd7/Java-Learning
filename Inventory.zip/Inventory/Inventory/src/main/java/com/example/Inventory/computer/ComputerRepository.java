package com.example.Inventory.computer;

import com.example.Inventory.computer.Computer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;
@Repository
public interface ComputerRepository extends JpaRepository<Computer,Long> {

    @Query("SELECT c FROM Computer c WHERE c.id = ?1")
    Optional<Computer> findComputerById(Long id);

    @Transactional
    @Modifying
    @Query("UPDATE Computer c SET c.assetTag = 'YYZ-005782' WHERE c.id = ?1")
    int updateComputerById(Long id);

    @Transactional
    @Modifying
    @Query("UPDATE Computer c SET c.serialNumber = '98765' WHERE c.id = ?1")
    int updateComputerSerialNumberById(Long id);


}
