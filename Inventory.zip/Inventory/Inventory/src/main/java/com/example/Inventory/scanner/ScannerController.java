package com.example.Inventory.scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("api/v1/scanners")
@RestController
public class ScannerController {

    private final ScannerService scannerService;

    @Autowired
    public ScannerController(ScannerService scannerService){
        this.scannerService = scannerService;
    }

    @GetMapping
    List<Scanner> getScanners(){
        return scannerService.getScanners();
    }


    @PostMapping
    void addScanner(@RequestBody Scanner scanner){
        scannerService.addScanner(scanner);
    }
}
