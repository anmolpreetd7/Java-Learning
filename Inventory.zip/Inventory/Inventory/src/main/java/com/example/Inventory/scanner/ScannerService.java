package com.example.Inventory.scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ScannerService {

    private final ScannerRepository scannerRepository;

    @Autowired
    public ScannerService(ScannerRepository scannerRepository){
        this.scannerRepository = scannerRepository;
    }

    List<Scanner>getScanners(){
        return scannerRepository.findAll();
    }

    void addScanner(Scanner scanner){
        scannerRepository.save(scanner);
    }
}
