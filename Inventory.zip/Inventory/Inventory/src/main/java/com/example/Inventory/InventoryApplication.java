package com.example.Inventory;

import com.example.Inventory.computer.Computer;
import com.example.Inventory.computer.ComputerRepository;
import com.example.Inventory.location.Location;
import com.example.Inventory.scanner.Scanner;
import com.example.Inventory.scanner.ScannerRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.time.LocalDate;
import java.util.List;

@SpringBootApplication
public class InventoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventoryApplication.class, args);
	}

	@Bean
	CommandLineRunner commandLineRunner(ScannerRepository scannerRepository, ComputerRepository computerRepository){
		return args -> {
			Scanner scanner = new Scanner("Honeywell","123456","YYZ-006475");
			Scanner scanner2 = new Scanner("Honeywell","987654","YYZ-006583");
			scanner.setLocation(new Location("Hogan"));
			scanner2.setLocation(new Location("Belgrave"));
//
//			scanner.setWarranty(new Warranty(LocalDate.of(2021,9,8),
//					true
//					));
//			scanner2.setWarranty(new Warranty(LocalDate.of(2021,10,11),true));
//
			scannerRepository.saveAll(List.of(scanner,scanner2));
//
////			Computer computer = new Computer("Lenovo","12345","YYZ-004532");
////			Computer computer2 = new Computer("Lenovo","987653","YYZ-0057823");
////			computer.setLocation(new Location("Belgrave"));
////			computer2.setLocation(new Location("Hogan"));
////
////			computer.setWarranty(new Warranty(LocalDate.of(2021,10,12),true));
////			computer2.setWarranty(new Warranty(LocalDate.of(2022,5,6),true));
////
////			computerRepository.saveAll(List.of(computer, computer2));
////
////			computerRepository.updateComputerById(2L);
////
////			computerRepository.updateComputerSerialNumberById(2L);
////
////			computerRepository.findComputerById(1L).ifPresent(System.out::println);
//
	};
	}

}
