package com.example.Inventory.location;

import com.example.Inventory.computer.Computer;
import com.example.Inventory.scanner.Scanner;
import lombok.*;

import javax.persistence.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity(name = "Location")
@Table(name = "location")
public class Location {
    @Id
    @SequenceGenerator(
            name = "location_sequence",
            sequenceName = "location_sequence",
            allocationSize = 1
    )
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "location_sequence"
    )
    @Column(name = "id",updatable = false)
    private Long id;

    @Column(name = "location_name",nullable = false,columnDefinition = "TEXT")
    private String locationName;

    @OneToOne(cascade = CascadeType.ALL,mappedBy = "location")
    private Scanner scanner;

    @OneToOne(cascade = CascadeType.ALL,mappedBy = "location")
    private Computer computer;

    public Location(String locationName){
        this.locationName = locationName;
    }
}
