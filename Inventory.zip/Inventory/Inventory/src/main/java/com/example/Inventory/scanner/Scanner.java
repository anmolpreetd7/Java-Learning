package com.example.Inventory.scanner;

import com.example.Inventory.location.Location;
import com.example.Inventory.warranty.Warranty;
import lombok.*;

import javax.persistence.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity(name = "Scanner")
@Table(name = "scanner",
    uniqueConstraints =
            {@UniqueConstraint(name = "scanner_serial_number_unique", columnNames = "serial_number"),
    @UniqueConstraint(name = "scanner_asset_tag_unique",columnNames = "asset_tag")}
)
public class Scanner {

    @Id
    @SequenceGenerator(
            name = "scanner_sequence",
            sequenceName = "scanner_sequence",
            allocationSize = 1
    )
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "scanner_sequence"
    )
    @Column(name = "id",updatable = false)
    private Long id;

    @Column(name = "model_name",nullable = false,columnDefinition = "TEXT")
    private String modelName;

    @Column(name = "serial_number",columnDefinition = "TEXT")
    private String serialNumber;

    @Column(name = "asset_tag",nullable = false,columnDefinition = "TEXT")
    private String assetTag;

    @OneToOne(cascade = CascadeType.ALL,orphanRemoval = true)
    @JoinColumn(name = "location_id",referencedColumnName = "id",
            foreignKey = @ForeignKey(name = "scanner_location_id_fk")
    )
    private Location location;

    @OneToOne(cascade = CascadeType.ALL,orphanRemoval = true)
    @JoinColumn(name = "warranty_id",referencedColumnName = "id",
            foreignKey = @ForeignKey(name = "scanner_warranty_id_fk")
    )
    private Warranty warranty;

    public Scanner(String modelName,String serialNumber,String assetTag){
        this.modelName = modelName;
        this.serialNumber = serialNumber;
        this.assetTag = assetTag;
    }
}
